import React from "react";
import { Outlet } from "react-router-dom";

const AppRoutes = () => {
  return <Outlet />;
};

export default AppRoutes;
