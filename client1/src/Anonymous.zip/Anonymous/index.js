import { Space } from "antd";
import AppHeader from "../../components/AppHeaderAnonymous";
import SideMenu from "../../components/SideMenuAnonymous";
import PageContent from "../../components/PageContent";

function Anonymous() {
  return (
    <div className="App">
      <AppHeader />
      <Space className="SideMenuAndPageContent">
        <SideMenu />
        <PageContent />
      </Space>
    </div>
  );
}

export default Anonymous;
